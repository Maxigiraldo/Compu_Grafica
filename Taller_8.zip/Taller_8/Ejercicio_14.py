import numpy as np
import matplotlib.pyplot as plt

imagen = np.array(plt.imread("fondo.jpg"))/255 # Normalizar la imagen

capa_grises = np.mean(imagen, axis=2) #average

plt.imshow(capa_grises)
plt.axis("off")

plt.show()