import numpy as np
import matplotlib.pyplot as plt

imagen = np.array(plt.imread("utp.jpg"))/255 # Normalizar la imagen

imagen[:,:,1] = imagen[:,:,0] = 0

plt.imshow(imagen)
plt.axis("off")
plt.show()