import numpy as np
import matplotlib.pyplot as plt

imagen = np.array(plt.imread("utp.jpg"))

imagen_invertida = 1 - (imagen/255)

plt.imshow(imagen_invertida)
plt.axis("off")
plt.show()