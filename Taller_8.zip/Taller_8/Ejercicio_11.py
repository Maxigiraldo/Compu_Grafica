import numpy as np
import matplotlib.pyplot as plt

img_1 = np.array(plt.imread("pista.jpg"))/255
img_2 = np.array(plt.imread("avion.jpg"))/255

img_3 = img_1 + img_2

plt.imshow(img_3)
plt.axis("off")
plt.show()
