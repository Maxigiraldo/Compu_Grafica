import numpy as np
import matplotlib.pyplot as plt

imagen = np.array(plt.imread("fondo.jpg"))/255 # Normalizar la imagen

capa_grises = (np.max(imagen, axis=2) + np.min(imagen, axis=2)) / 2 # midgray

plt.imshow(capa_grises, cmap="gray")
plt.axis("off")

plt.show()