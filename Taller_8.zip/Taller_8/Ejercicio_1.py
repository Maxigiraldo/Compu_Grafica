import numpy as np
import matplotlib.pyplot as plt

matriz = np.ones((3,3,3))
matriz[0,2,1] = matriz[0,2,2] = 0
matriz[1,2,0] = matriz[1,2,2] = 0
matriz[2,2,0] = matriz[2,2,1] = 0
matriz[1,1,:] = 0.5
matriz[2,1,:] = 0
matriz[0,0,0] = 0
matriz[1,0,1] = 0
matriz[2,0,2] = 0

plt.imshow(matriz)

plt.show()