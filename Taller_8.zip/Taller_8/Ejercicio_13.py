import numpy as np
import matplotlib.pyplot as plt

img_1 = np.array(plt.imread("playa.jpg"))/255

factor = 0.3

img_ecualizada = img_1 * factor

plt.subplot(1, 2, 1)
plt.imshow(img_1)
plt.axis("off")
plt.title("Imagen original")

plt.subplot(1, 2, 2)
plt.imshow(img_ecualizada)
plt.axis("off")
plt.title("Imagen ecualizada")

plt.axis("off")
plt.show()
