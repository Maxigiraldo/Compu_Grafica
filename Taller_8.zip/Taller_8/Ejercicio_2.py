import numpy as np 
import matplotlib.pyplot as plt 

matriz=np.ones((8,11,3)) 
matriz[:6,0,2]=0 
matriz [:6,1:3,0]=0 
matriz [:6,3:5,0]=matriz[:6,3:5,2]=0 
matriz [:6,5:7,1]=0 
matriz[:6,7:9,1]=matriz[:6,7:9,2]=0 
matriz[:6,9:11,1]=matriz [:6,9:11,0]=0 
matriz [6:8,1,:]=0.9 
matriz [6:8,2,:]=0.7 
matriz [6:8,3,:]=0.6 
matriz [6:8,4,:]=0.5 
matriz [6:8,5,:]=0.3 
matriz [6:8,6,:]=0.2 
matriz [6:8,7,:]=0.1 
matriz [6:8,8,:]=0.1 
matriz [6:8,9,:]=0.1 
matriz [6:8,10,:]=0.1

factor=0.6
matriz=matriz*factor 

plt.imshow(matriz) 

plt.axis("off") 

plt.show() 