import numpy as np
import matplotlib.pyplot as plt

imagen = np.array(plt.imread("utp.jpg"))/255 # Normalizar la imagen

capa_roja = np.copy(imagen)
capa_roja[:,:,1] = capa_roja[:,:,2] = 0
capa_verde = np.copy(imagen)
capa_verde[:,:,0] = capa_verde[:,:,2] = 0
capa_azul = np.copy(imagen)
capa_azul[:,:,0] = capa_azul[:,:,1] = 0

capa_original = capa_roja + capa_verde + capa_azul

plt.subplot(1,4,1)
plt.imshow(capa_roja)
plt.axis("off")
plt.subplot(1,4,2)
plt.imshow(capa_verde)
plt.axis("off")
plt.subplot(1,4,3)
plt.imshow(capa_azul)
plt.axis("off")

plt.subplot(1,4,4)
plt.imshow(capa_original)
plt.axis("off")

plt.show()
