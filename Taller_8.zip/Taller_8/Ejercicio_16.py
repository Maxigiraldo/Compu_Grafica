import numpy as np
import matplotlib.pyplot as plt

imagen = np.array(plt.imread("fondo.jpg"))/255 # Normalizar la imagen

capa_grises =  0.2989*imagen[:,:,0] + 0.5870*imagen[:,:,1] + 0.1140*imagen[:,:,2] #luminosity

plt.imshow(capa_grises, cmap="gray")
plt.axis("off")

plt.show()